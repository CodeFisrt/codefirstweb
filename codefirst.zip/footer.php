
    <!-- End Footer Area -->
    <footer class="footer-area with-black-background margin-zero pt-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 col-md-12 text-center">
                    <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="50" data-aos-duration="500"
                        data-aos-once="true">
                        <!-- <div class="widget-logo">
                            <a href="index.html"><img src="assets/images/logo.png" alt="image"></a>
                        </div> -->
                        <!-- <p>Lorem ipsum dolor sit amet consetetur sadi scing elitr sed diam nonumy.</p> -->
                        <h3>Follow Us</h3>
                        <h4>hello</h4>
                        <ul class="widget-social">
                            <li>
                               
                                <a href="https://www.facebook.com/profile.php?id=100083792171064" target="_blank">
                                   
                                    <i class="ri-facebook-fill"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/?lang=en" target="_blank">
                                    <i class="ri-twitter-fill"></i>
                                </a>
                            </li>

                            <li>
                                <a href="https://www.youtube.com/" target="_blank">
                                    <i class="ri-youtube-fill"></i>
                                </a>
                            </li>

                            <li>
                                <a href="https://linkedin.com/" target="_blank">
                                    <i class="ri-linkedin-fill"></i>
                                </a>
                            </li>

                            <li>
                                <a href="https://www.instagram.com/" target="_blank">
                                    <i class="ri-instagram-line"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- <div class="col-lg-3 col-md-6">
                    <div class="single-footer-widget ps-5" data-aos="fade-up" data-aos-delay="60"
                        data-aos-duration="600" data-aos-once="true">
                        <h3>Links</h3>

                        <ul class="quick-links">
                            <li><a href="about-style-1.html">About Us</a></li>
                            <li><a href="services-style-2.html">Services</a></li>
                            <li><a href="blog-style-1.html">Blogs</a></li>
                            <li><a href="pricing.html">Cources</a></li>
                            <li><a href="projects.html">Projects</a></li>
                        </ul>
                    </div>
                </div> -->

                <!-- <div class="col-lg-3 col-md-6">
                    <div class="single-footer-widget ps-5" data-aos="fade-up" data-aos-delay="70"
                        data-aos-duration="700" data-aos-once="true">
                        <h3>Pages</h3>

                        <ul class="quick-links">
                            <li><a href="contact.html">Contact Us</a></li>
                            <li><a href="purchase-guide.html">Purchase Guide</a></li>
                            <li><a href="faq.html">FAQ's</a></li>
                            <li><a href="terms-of-service.html">Terms of Service</a></li>
                            <li><a href="privacy-policy.html">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div> -->

                <!-- <div class="col-lg-3 col-md-6">
                    <div class="single-footer-widget" data-aos="fade-up" data-aos-delay="80" data-aos-duration="800"
                        data-aos-once="true">
                        <h3>Subscribe Newsletter</h3>

                        <form class="newsletter-form" data-bs-toggle="validator">
                            <input type="email" class="input-newsletter" placeholder="Enter your email" name="EMAIL"
                                required autocomplete="off">

                            <button type="submit" class="default-btn">Subscribe</button>
                            <div id="validator-newsletter" class="form-result"></div>
                        </form>
                    </div>
                </div> -->
            </div>
        </div>

      
        <div class="footer-shape-1">
            <img src="assets/images/footer/footer-shape-1.png" alt="image">
        </div>
        <div class="footer-shape-2">
            <img src="assets/images/footer/footer-shape-2.png" alt="image">
        </div>
        <div class="footer-shape-3">
            <img src="assets/images/footer/footer-shape-3.png" alt="image">
        </div>
    </footer>
    <!-- End Footer Area -->

    <!-- Start Go Top Area -->
    <div class="go-top">
        <i class="ri-arrow-up-s-line"></i>
    </div>
    <!-- End Go Top Area -->

    <!-- Links of JS files -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.meanmenu.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/odometer.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/fancybox.min.js"></script>
    <script src="assets/js/tweenmax.min.js"></script>
    <script src="assets/js/ScrollMagic.min.js"></script>
    <script src="assets/js/animation.gsap.min.js"></script>
    <script src="assets/js/debug.addIndicators.min.js"></script>
    <script src="assets/js/mixitup.min.js"></script>
    <script src="assets/js/nice-select.min.js"></script>
    <script src="assets/js/tilt.jquery.min.js"></script>
    <script src="assets/js/parallax.min.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="assets/js/form-validator.min.js"></script>
    <script src="assets/js/contact-form-script.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

<!-- Mirrored from templates.envytheme.com/coze/default/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Sep 2022 05:07:49 GMT -->

</html>